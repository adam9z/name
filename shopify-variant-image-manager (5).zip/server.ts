import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";

async function startServer() {
  const app = express();
  const PORT = process.env.PORT || 3000;

  app.use(express.json());

  // API Routes pour l'application Shopify
  // Dans une vraie application, vous utiliseriez @shopify/shopify-api ici
  // pour gérer l'OAuth et les requêtes GraphQL vers l'API Admin de Shopify.
  
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "Shopify App Backend Running" });
  });

  // Mock API pour récupérer les produits (à remplacer par l'appel GraphQL Shopify)
  app.get("/api/products", (req, res) => {
    res.json([
      {
        id: "gid://shopify/Product/1",
        title: "T-Shirt Premium",
        images: [
          { id: "img1", url: "https://picsum.photos/seed/tshirt-black-1/400/400" },
          { id: "img2", url: "https://picsum.photos/seed/tshirt-black-2/400/400" },
          { id: "img3", url: "https://picsum.photos/seed/tshirt-white-1/400/400" },
          { id: "img4", url: "https://picsum.photos/seed/tshirt-white-2/400/400" }
        ],
        variants: [
          { id: "var1", title: "Noir / M", assignedImages: ["img1", "img2"] },
          { id: "var2", title: "Blanc / M", assignedImages: ["img3", "img4"] }
        ]
      },
      {
        id: "gid://shopify/Product/2",
        title: "Sneakers Urban",
        images: [
          { id: "img5", url: "https://picsum.photos/seed/sneaker-red/400/400" },
          { id: "img6", url: "https://picsum.photos/seed/sneaker-blue/400/400" }
        ],
        variants: [
          { id: "var3", title: "Rouge / 42", assignedImages: ["img5"] },
          { id: "var4", title: "Bleu / 42", assignedImages: ["img6"] }
        ]
      }
    ]);
  });

  // Vite middleware pour le développement
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
