import { useState, useEffect } from 'react';
import { Layers, Image as ImageIcon, CheckCircle2, Search, Save, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface ProductImage {
  id: string;
  url: string;
}

interface Variant {
  id: string;
  title: string;
  assignedImages: string[];
}

interface Product {
  id: string;
  title: string;
  images: ProductImage[];
  variants: Variant[];
}

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedVariant, setSelectedVariant] = useState<Variant | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    // Simulation d'un appel API vers notre backend (qui appellerait Shopify GraphQL)
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        setProducts(data);
        setLoading(false);
      });
  }, []);

  const handleToggleImage = (imageId: string) => {
    if (!selectedProduct || !selectedVariant) return;

    const updatedVariant = { ...selectedVariant };
    if (updatedVariant.assignedImages.includes(imageId)) {
      updatedVariant.assignedImages = updatedVariant.assignedImages.filter(id => id !== imageId);
    } else {
      updatedVariant.assignedImages.push(imageId);
    }

    setSelectedVariant(updatedVariant);

    // Mettre à jour le produit dans l'état local
    const updatedProduct = { ...selectedProduct };
    const variantIndex = updatedProduct.variants.findIndex(v => v.id === updatedVariant.id);
    updatedProduct.variants[variantIndex] = updatedVariant;
    setSelectedProduct(updatedProduct);

    const updatedProducts = products.map(p => p.id === updatedProduct.id ? updatedProduct : p);
    setProducts(updatedProducts);
  };

  const handleSave = () => {
    setSaving(true);
    // Simulation de sauvegarde vers les Metafields Shopify
    setTimeout(() => {
      setSaving(false);
      alert('Images assignées sauvegardées avec succès dans les Metafields de la variante !');
    }, 1000);
  };

  const filteredProducts = products.filter(p => p.title.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col">
      {/* Header (Simule la barre supérieure de Shopify Admin) */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="bg-emerald-100 p-2 rounded-lg">
            <Layers className="w-6 h-6 text-emerald-600" />
          </div>
          <h1 className="text-xl font-semibold">Variant Image Manager</h1>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-slate-500">Connecté à: <b>mon-boutique.myshopify.com</b></span>
          <button 
            onClick={handleSave}
            disabled={saving || !selectedProduct}
            className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {saving ? 'Sauvegarde...' : 'Sauvegarder'}
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Sidebar: Liste des produits */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col h-[calc(100vh-8rem)]">
            <div className="p-4 border-b border-slate-200">
              <h2 className="font-semibold mb-3">Produits</h2>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Rechercher un produit..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto p-2">
              {loading ? (
                <div className="flex justify-center p-8 text-slate-400">Chargement...</div>
              ) : (
                <ul className="space-y-1">
                  {filteredProducts.map(product => (
                    <li key={product.id}>
                      <button
                        onClick={() => {
                          setSelectedProduct(product);
                          setSelectedVariant(product.variants[0]);
                        }}
                        className={`w-full text-left px-4 py-3 rounded-lg text-sm transition-colors flex items-center justify-between ${
                          selectedProduct?.id === product.id 
                            ? 'bg-emerald-50 text-emerald-700 font-medium' 
                            : 'hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <span className="truncate">{product.title}</span>
                        <span className="text-xs bg-white border border-slate-200 px-2 py-1 rounded-full text-slate-500">
                          {product.variants.length} var.
                        </span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* Main Content: Variantes et Images */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {!selectedProduct ? (
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-full flex flex-col items-center justify-center text-slate-400 p-12">
              <ImageIcon className="w-16 h-16 mb-4 opacity-20" />
              <p className="text-lg font-medium text-slate-600">Sélectionnez un produit</p>
              <p className="text-sm text-center mt-2 max-w-md">
                Choisissez un produit dans la liste de gauche pour assigner des images spécifiques à ses variantes.
              </p>
            </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col gap-6"
            >
              {/* Sélecteur de variante */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h2 className="text-lg font-semibold mb-4">1. Sélectionnez une variante</h2>
                <div className="flex flex-wrap gap-2">
                  {selectedProduct.variants.map(variant => (
                    <button
                      key={variant.id}
                      onClick={() => setSelectedVariant(variant)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all ${
                        selectedVariant?.id === variant.id
                          ? 'bg-slate-900 border-slate-900 text-white shadow-md'
                          : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300 hover:bg-slate-50'
                      }`}
                    >
                      {variant.title}
                      <span className={`ml-2 text-xs px-1.5 py-0.5 rounded-full ${
                        selectedVariant?.id === variant.id ? 'bg-slate-700 text-slate-200' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {variant.assignedImages.length} img
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Grille d'images */}
              <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold">2. Assignez des images</h2>
                  <span className="text-sm text-slate-500">
                    Cliquez sur les images pour les lier à la variante <b>{selectedVariant?.title}</b>
                  </span>
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {selectedProduct.images.map(image => {
                    const isAssigned = selectedVariant?.assignedImages.includes(image.id);
                    return (
                      <div 
                        key={image.id}
                        onClick={() => handleToggleImage(image.id)}
                        className={`relative aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                          isAssigned ? 'border-emerald-500 shadow-md' : 'border-transparent hover:border-slate-300'
                        }`}
                      >
                        <img 
                          src={image.url} 
                          alt="Product" 
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className={`absolute inset-0 transition-opacity ${isAssigned ? 'bg-emerald-500/20' : 'bg-black/0 hover:bg-black/5'}`} />
                        
                        {isAssigned && (
                          <div className="absolute top-2 right-2 bg-emerald-500 text-white rounded-full p-0.5 shadow-sm">
                            <CheckCircle2 className="w-5 h-5" />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div className="mt-6 bg-blue-50 border border-blue-100 rounded-lg p-4 flex gap-3 text-blue-800">
                  <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium mb-1">Comment ça marche sur la boutique ?</p>
                    <p className="opacity-90">
                      Une fois sauvegardées, ces images sont stockées dans les <b>Metafields</b> de la variante. 
                      Vous devrez ajouter un petit bout de code Liquid dans votre thème Shopify pour que seules ces images s'affichent lorsque le client sélectionne cette variante.
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </main>
    </div>
  );
}
